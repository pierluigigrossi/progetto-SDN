#!/bin/bash
#sudo mn --topo=linear,3   --controller=remote 
sudo mn --custom mesh-topology.py --topo MeshTopo --controller=remote

