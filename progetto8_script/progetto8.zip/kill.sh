#!/bin/bash
sudo killall tcpdump
sudo killall iperf.sh
sudo killall iperf